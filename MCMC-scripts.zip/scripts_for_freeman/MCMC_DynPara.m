function [para_vec,acceptance_vec,LogPosterior_vec,sim_data] = MCMC_DynPara(para0,dyn_sys,prior,exp_observables,...
    data_file_name,cond_idx,num_iti,delta_para,minstd,num_ini,save_traj_itvl)
% Dyn_LogLikelihood_ExpPool(exp_states,data_files,cond_idx,para_current,dyn_sys)
% Adaptive MCMC to identify dynamical system parameters.
% Need to have the following files in the same directory:
% 1. dyn_sys.m [dynamical sys to simulate]
% 2. LogPrior.m [parameter prior distribution upto a normalization const. Take log.]
%%%%%%%%%%%%%
% Inputs:
% para0 - initial guess of the parameters [row vector 1 x p, p = # of parameters]
% dyn_sys - dynamical system to simulate [use function handle to specify]
% time - measurement time points [column vector N x 1, N = # of temporal points]
% X0 - initial condition of dynamical system [column vector 1xn, b = # of states]
% mean_meas - measured mean value [matrix N x n]
% std_meas - measured standard deviation [matrix N x n]
% num_iti - total number of iterations [positive integer]
% burn_in - # of iterations to discard as burn-in [poisitve integer << num_iti]
% step_ini - initial std of proposal (normal) distribution before
% adaptation begines [row vector 1xp]
% minstd - minimum standard deviation. experimentally measured std below
% this should be increased to this value. this is a small parameter to
% avoid numerical issue evaluating pdfs.
% num_ini - number of initial conditions to estimate
%%%%%%%%%%%%
% Outputs:
% para_vec - (parameter) sample trajectory from MCMC [matrix num_iti x p]
% acceptance_vec - whether a (parameter) sample is accepted (1) or rejected (0) [vector num_itix1]
% LogPosterior_vec - loglikelihood of each sample
% X_vec - simulated trajectory for each sample

%% set up
% get the number of parameters
num_parameters = length(para0);

% records log likelihood (start with index 0 to always accept the first sample)
LogPosterior_vec = -inf*ones(num_iti+1,1);

% records if a sample is accepted or not
acceptance_vec = zeros(num_iti,1);

% acceptance probability
a_vec = zeros(num_iti+1,1);

% sampled r vector
para_vec = zeros(num_iti+1,num_parameters);

% % store trajectory produced by each stochastic parameter sample
% sim_data = cell(num_iti,1);

% generate uniform sample from [0,1] to compare with acceptance ratio take
% log because the likelihoods are also in log
seed = log((rand(num_iti,1)));

% generate normal sample from [0,1] to perform Markovian jump
para_seed_jump = randn(num_iti,num_parameters);

%% compute loglikelihood of para0
% loglikelihood associated with dynamic measurements
[LogLikelihood_dyn,sim_data_temp] = Dyn_LogLikelihood_ExpPool_v3(exp_observables,data_file_name,cond_idx,para0,dyn_sys,minstd,num_ini);

sim_data_temp_current = sim_data_temp;

% compute log posterior
% the second the third arguments in LogPrior are deterministic fits
LogPosterior = LogLikelihood_dyn + prior(para0,num_ini);

LogPosterior_vec(1) = LogPosterior;

%% run Markov chain
para_vec(1,:) = para0;

% current state of parameters
para_current = para0;

% this keeps track of number of trajectories saved
QQ = 1;
for j = 2:1:num_iti+1
    
    % display progress every 100 jumps
    if mod(j,100) == 0
        display(['iteration ' num2str(j)])
    end
    
    % propose next jump state
    para_current = para_current + para_seed_jump(j-1,:).*delta_para;
    
    prior_current = prior(para_current,num_ini);
    
    if prior_current ~= -inf
        % compute log likelihood
        [LogLikelihood_dyn,sim_data_temp] = Dyn_LogLikelihood_ExpPool_v3(exp_observables,data_file_name,cond_idx,para_current,dyn_sys,minstd,num_ini);
        LogPosterior = LogLikelihood_dyn + prior_current;
    else
        LogPosterior = -inf;
    end
    
    % log acceptance ratio
    a = min(0,LogPosterior-LogPosterior_vec(j-1));
    a_vec(j-1) = a;
    
    if a > seed(j-1)
        % if greater than seed, accept, record parameter sample and likelihood
        acceptance_vec(j-1) = 1;
        
        para_vec(j,:) = para_current;
        
        LogPosterior_vec(j) = LogPosterior;
        
        % update sim data as current
        sim_data_temp_current = sim_data_temp;
        
        if mod(j,save_traj_itvl) == 0
            sim_data{QQ,1} = sim_data_temp_current;
            QQ = QQ + 1;
        end
        
    else
        % if less than seed, reject, do not record parameter, replace
        % likelihood with previous likelihood
        acceptance_vec(j-1) = 0;
        
        para_vec(j,:) = para_vec(j-1,:);
        
        para_current = para_vec(j-1,:);
        
        LogPosterior_vec(j) = LogPosterior_vec(j-1);
        
        if mod(j,save_traj_itvl) == 0
            sim_data{QQ,1} = sim_data_temp_current;
            QQ = QQ + 1;
        end
    end
end