clear all
close all
clc
warning off
%%
num_cond = 3;    % num of initial conditions

data_file_name = 'Data_rearranged';

load(data_file_name);
%% MCMC setup
dyn_sys = @CME_flippling;

prior = @LogPrior_CME;

num_iti = 200;   % number of samples generated

num_para = 14;   % number of parameters to infer
num_ini = 0;    % number of initial parameters to infer

% store a trajectory every xxx iterations
save_traj_itvl = 10;

disp(['check seed is updated, num_iti=' num2str(num_iti) ', prior is "' func2str(prior) '.m"'])
%% initialization parameters

para0 = 0.01*ones(1,num_para);    % [initial parameter guess]

delta_para = 0.01*para0; % std of the proposal normal distribution

if length(para0) ~= num_para+num_ini
    disp('check initial condition dimension')
end

minstd = 5*10^-2;   % this parameter is inherited from Jun project but useless/redundant here, since we use a regression model to find mean vs std relationship
%% set up experimental data
exp_observables = state_idx_vec;  % observable states (inherited from Susan project, 1:128 in BF project)
cond_idx = num2cell(1:1:length(data_mean_vec)); % cells in the experimental data file to read as exp data

[para_vec,acceptance_vec,LogPosterior_vec,sim_data] = MCMC_DynPara(para0,dyn_sys,prior,exp_observables,...
    data_file_name,cond_idx,num_iti,delta_para,minstd,num_ini,save_traj_itvl);

acceptance_rate = movmean(acceptance_vec,50);

%% save
FileName = ['MCMC_' datestr(now,'dd-mm-yyyy HH:MM:SS')];

save(FileName,'para_vec','acceptance_vec','LogPosterior_vec','num_iti','delta_para','acceptance_rate','acceptance_rate','dyn_sys','prior','data_file_name','minstd','exp_observables','cond_idx','sim_data');