function [LogLikelihood,sim_data] = Dyn_LogLikelihood_ExpPool_v3(exp_observables,data_file_name,cond_idx,para_current,dyn_sys,minstd,num_ini)
% Dyn_LogLikelihood_ExpPool(exp_species,data_files,cond_idx,para_current,dyn_sys)
% pool together the likelihood of a set of parameter over all experimental
% conditions. Let L be the number of experimental data sets.
% Input:
% - exp_species: 1 x L cell. Each cell contains a vector 1 x num_species in
% size that specifies the columns in each data file (which corresponds to
% species) that should be read.
% - data files: 1 x L cell. Each cell contains a string specifies the
% experimental data files to read.
% - cond_idx: 1 x L cell. Which conditions needs to be read in each data
% file. Each data file should contain a cell (1xnum_conditions size). Each
% cell contains the data for that specific doncition.
% - minstd: minimum standard deviation from experimental data. std below
% this limit will be increased to this value. this number should be small
% and only functions to avoid numerical issue. 
% Output:
% - Loglikelihood: posterior log likelihood of all data sets summed
% together.
% - sim_data: 1xL cell. Each cell contains the temporal trace of the
% species, simulated using the sample parameter, at the experimental time. 

% number of experimental data sets to pool together
L = length(exp_observables);

% cumulative likelihood
LogLikelihood_cum = 0;

% this loads the data from all experimental conditions
[T,Y_mean,Y_std] = LoadFileFcn(data_file_name);

% stores trajectory (at experimental data point) for each experiment
sim_data = cell(1,L);

for i = 1:1:L
    
    y_mean = Y_mean{cond_idx{i}};
    y_std = Y_std{cond_idx{i}};
    y_std = max(y_std,minstd); 
    
    % use the first measurement as initial condition
    X0 = y_mean(1,:);
    
    % log likelihood and simulated data from a single experiment 
    [Dyn_LogLikelihood_temp,sim_data_temp] = Dyn_LogLikelihood_SingleExp_v4(para_current,dyn_sys,exp_observables{i},T{i},X0,y_mean,y_std,num_ini,i);
    
    LogLikelihood_cum = LogLikelihood_cum + Dyn_LogLikelihood_temp;
    
    sim_data{1,i} = sim_data_temp;
end
LogLikelihood = LogLikelihood_cum;