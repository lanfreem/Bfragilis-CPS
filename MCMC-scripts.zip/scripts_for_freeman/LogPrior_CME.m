function y = LogPrior_CME(para,num_ini)

num_para = length(para);

uni_low = zeros(1,num_para);
uni_high = ones(1,num_para);

y = log(prod(unifpdf(para(1:num_para-num_ini),uni_low,uni_high)));