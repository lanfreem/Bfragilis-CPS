function [LogLikelihood,sim_data] = Dyn_LogLikelihood_SingleExp_v4(para_current,dyn_sys,exp_observables,time,X0,Y_mean,Y_std,num_ini,exp_num)
% Dyn_LogLikelihood_SingleExp(para_current,dyn_sys,time,X0,Y_mean,Y_std)
% compute likelihood of a sample parameter para_current given measurement Y,
% measurement noise Y_std, sampling time
% Input:
% - para_current: parameter sampled [1 x p vector]
% - dyn_sys: simulated function
% - time: sampling time [N x 1 vector]
% - species_idx: take into account the dynamics of which species specified
% by vector
% - X0: initial condition [n x 1 vector]
% - Y_mean: experimentally meausred mean [N x num_outputs]
% - Y_std: experimentally measured std [N x num_outputs]
% v4: added exp observeables into the function when only partial states are
% available in experiments
% v4: added initial conditions to estimate

L = length(time);

% separate parameters and initial conditions to estimate
D = length(para_current);

para = para_current(1:D-num_ini);

% [t_sim,X_sim] = ode15s(@(t,x) dyn_sys(t,x,para),[0 max(time)],X0);
X_sim = CME_flipping(X0,para,time);

% only leave the observable
X_sim = X_sim(:,exp_observables);

X = X_sim;
[~,W_sim] = size(X);

if sum(isnan(X),'all') == 0
    p_y_theta = zeros(L-1,1);   % compute likelihood of each temporal data point, remove initial point since it is deterministic
    sim_data = X;
    
    for i = 1:1:L-1
        for j = 1:1:W_sim
            % evaluate likelihood: assume channels are independent, the std
            % is from fit of mean vs std data
            if max(-15,log10(Y_mean(i+1,j)))> -3
                p_y_theta(i) = p_y_theta(i) + log(normpdf(log10(X(i+1,j)),max(-15,log10(Y_mean(i+1,j))),-0.0276*max(-15,log10(Y_mean(i+1,j)))+0.01556));
            end
        end
    end
    
    LogLikelihood = sum(p_y_theta);
else
    LogLikelihood = -inf;
end

function y = lognormalpdf(x,y_mean,y_std)

if sum(isnan(y_mean)) == 0
    y = log(normpdf(x,y_mean,y_std));
else
    y = 0;
end