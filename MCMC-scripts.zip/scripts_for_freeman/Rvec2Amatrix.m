function A = Rvec2Amatrix(R_vec,assignment)

num_states = assignment.num_states;
num_promoters = assignment.num_promoters;

R_matrix = reshape(R_vec,num_promoters,2);
A = zeros(num_states,num_states);

for i = 1:num_states
    for j = 1:num_states
        if assignment.sign(i,j)~= 0
            temp_rate = R_matrix(assignment.flipidx(i,j),min(-assignment.sign(i,j)+2,2));
            A(i,j) = temp_rate;
        end
    end
end

A_col_sum = sum(A,1);

for i = 1:num_states
    A(i,i) = -A_col_sum(i);
end