function X = CME_flipping(X0,para,time)

load('A_matrix_assignment');
assignment.sign = neighbor_ind_matrix;
assignment.flipidx = neighbor_ind_flip_matrix;

assignment.num_promoters = 7;
assignment.num_states = 2^assignment.num_promoters;

A = Rvec2Amatrix(para,assignment);

X(1,:) = X0;
for i = 2:length(time)
    X(i,:) = expm(A*(max(time(i),0)))*X0';
end