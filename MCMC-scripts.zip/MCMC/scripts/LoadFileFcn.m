function [T,Y_mean,Y_std] = LoadFileFcn(dataFileName)
load(dataFileName)
T = time_vec;
Y_mean = data_mean_vec;
Y_std = data_std_vec;