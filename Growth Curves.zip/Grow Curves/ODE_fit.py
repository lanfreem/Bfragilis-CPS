#Here's one with flexible model types to use

import numpy as np
import math
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib as mpl
from labellines import labelLine, labelLines
import seaborn as sns
import scipy as sp
from scipy.integrate import odeint
from scipy.optimize import least_squares as ls

#functions to fit gLV_monospecies model to data
#Useage - call fit() with initial params, bounds, and the experimental data to fit the model to the data.
#call plotfit with the output of fit() and data to plot the model fit vs data.

#this is the gLV ODE function that will be used to fit the data
#OD = OD, t = timestamps, r = growth rate, alpha = self interaction param
def monogLV(OD, t, r, alpha): 
    dODdt = OD*(r + OD*alpha) #monospecies gLV
    return dODdt

#this function will calculate the residuals between the exp data and the fit
#x = the parameters for the model (r, alpha, y0), index = the index for the experimental dataset
def residuals(params, data, model): 
    #unpack the variables
    y0 = params[-1] #starting OD is the last param
    t = data.index
    #calculate the fit, which is model result - real result, squared
    model_result = odeint(model, y0, t, args = tuple(params[:-1])) #the rest of the params   
    model_OD=[item[0] for item in model_result]
    
    #calculating residuals (model OD - experimental OD (divided by avgOD))
    averageOD = sum(model_OD)/len(model_OD)
    res = [(a - b)/averageOD for a, b in zip(model_OD,data)]
    #print ([b for a, b in zip(model_OD,data.loc[condition])])
    return res

#this function just uses the least squares function of scipy to fit the data
#x0 is the initial params (r, alpha, and y0), data is the experimental dataset to fit
def fit(x0, low_bounds, up_bounds, data, model):
    #using least squares to fit the data
    fitted_params = ls(residuals, x0, bounds=(low_bounds, up_bounds), args = [data, model])
    return fitted_params

#this function plot the fitted vs the data - fitted_params is the output of the fit function, index is the experimental data condition
def plotfit(fitted_params, data, model):
    y0 = fitted_params.x[-1]
    t = data.index
    model_result = odeint(model, y0, t, args = tuple(fitted_params.x[:-1]))
    model_OD=[item[0] for item in model_result]
    plt.plot(data)
    plt.plot(t, model_result)
    return model_result
