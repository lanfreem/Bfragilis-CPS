Here are scripts for conducting the growth rate analysis for the different B. fragilis strains. 

monogLV_functions.py contains the necessary functions to fit data to a mono-species gLV (logistics growth) model.

ODE_fit.py contains functions to fit ODE models (such as the logistics growth model).

Grow-curve-analysis.ipynb contains the analysis of the raw OD600 growth data for different B. fragilis strains in a Juypter notebook format.